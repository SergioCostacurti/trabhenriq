class SistemaMatricula {
    void matricular(String idAluno, String idCurso) {
        System.out.println("Aluno " + idAluno + " matriculado no curso " + idCurso);
    }
}