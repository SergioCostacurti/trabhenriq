class Biblioteca implements Observador {
    public void atualizar(String info) {
        System.out.println("Biblioteca notificada: " + info);
    }
}