class FacadeEscola {
    SistemaMatricula matricula = new SistemaMatricula();

    void registrarAluno(String idAluno, String idCurso) {
        matricula.matricular(idAluno, idCurso);
        System.out.println("Pagamento e registro acadêmico atualizados para o aluno " + idAluno);
    }
}