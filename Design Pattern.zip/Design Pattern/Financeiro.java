class Financeiro implements Observador {
    public void atualizar(String info) {
        System.out.println("Financeiro notificado: " + info);
    }
}