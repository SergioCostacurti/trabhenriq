import java.util.ArrayList;
import java.util.List;

class Aluno {
    List<Observador> observadores = new ArrayList<>();

    void adicionarObservador(Observador obs) {
        observadores.add(obs);
    }

    void notificarTodos(String info) {
        for (Observador obs : observadores) {
            obs.atualizar(info);
        }
    }

    void mudarStatus(String novoStatus) {
        notificarTodos("Status do aluno mudou para " + novoStatus);
    }
}