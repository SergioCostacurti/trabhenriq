interface Observador {
    void atualizar(String info);
}