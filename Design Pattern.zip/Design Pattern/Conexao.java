class Conexao {
    private static Conexao instancia = new Conexao();

    private Conexao() {}

    static Conexao obter() {
        return instancia;
    }

    void conectar() {
        System.out.println("Conectado ao banco de dados.");
    }
}